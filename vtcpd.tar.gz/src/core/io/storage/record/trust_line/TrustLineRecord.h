#ifndef VTCPD_TRUSTLINERECORD_H
#define VTCPD_TRUSTLINERECORD_H

#include "../base/Record.h"

#include "../../../../common/memory/MemoryUtils.h"
#include "../../../../common/multiprecision/MultiprecisionUtils.h"

class TrustLineRecord: public Record
{
public:
    typedef shared_ptr<TrustLineRecord> Shared;

public:
    enum TrustLineOperationType
    {
        Opening = 1,
        Accepting,
        Setting,
        Updating,
        Closing,
        Rejecting,
        ClosingIncoming,
        RejectingOutgoing
    };
    typedef uint8_t SerializedTrustLineOperationType;

public:
    TrustLineRecord(
        const TransactionUUID &operationUUID,
        const TrustLineRecord::TrustLineOperationType operationType,
        Contractor::Shared contractor);

    TrustLineRecord(
        const TransactionUUID &operationUUID,
        const TrustLineRecord::TrustLineOperationType operationType,
        Contractor::Shared contractor,
        const TrustLineAmount &amount);

    TrustLineRecord(
        const TransactionUUID &operationUUID,
        const GEOEpochTimestamp geoEpochTimestamp,
        BytesShared recordBody);

    const TrustLineOperationType trustLineOperationType() const;

    const TrustLineAmount amount() const;

    const bool isTrustLineRecord() const override;

    pair<BytesShared, size_t> serializedHistoryRecordBody() const override;

private:
    TrustLineOperationType mTrustLineOperationType;
    TrustLineAmount mAmount;
};

#endif //VTCPD_TRUSTLINERECORD_H
