#ifndef VTCPD_INTERFACES_AUDITHANDLER_H
#define VTCPD_INTERFACES_AUDITHANDLER_H

#include "../../../logger/Logger.h"
#include "../../../common/Types.h"
#include "../../../common/multiprecision/MultiprecisionUtils.h"
#include "../../../common/exceptions/IOError.h"
#include "../../../common/exceptions/NotFoundError.h"
#include "../../../common/exceptions/ValueError.h"
#include "../../../crypto/lamportscheme.h"
#include "../record/audit/AuditRecord.h"

#include <vector>
#include <memory>

using namespace std;
using namespace crypto;

class AuditHandler
{
public:
    virtual ~AuditHandler() = default;

    virtual void saveFullAudit(
        AuditNumber number,
        TrustLineID trustLineID,
        lamport::KeyHash::Shared ownKeyHash,
        lamport::Signature::Shared ownSignature,
        lamport::KeyHash::Shared contractorKeyHash,
        lamport::Signature::Shared contractorSignature,
        lamport::KeyHash::Shared ownKeysSetHash,
        lamport::KeyHash::Shared contractorKeysSetHash,
        const TrustLineAmount &incomingAmount,
        const TrustLineAmount &outgoingAmount,
        const TrustLineBalance &balance) = 0;

    virtual void saveOwnAuditPart(
        AuditNumber number,
        TrustLineID trustLineID,
        lamport::KeyHash::Shared ownKeyHash,
        lamport::Signature::Shared ownSignature,
        lamport::KeyHash::Shared ownKeysSetHash,
        lamport::KeyHash::Shared contractorKeysSetHash,
        const TrustLineAmount &incomingAmount,
        const TrustLineAmount &outgoingAmount,
        const TrustLineBalance &balance) = 0;

    virtual void saveContractorAuditPart(
        AuditNumber number,
        TrustLineID trustLineID,
        lamport::KeyHash::Shared contractorKeyHash,
        lamport::Signature::Shared contractorSignature) = 0;

    virtual const AuditRecord::Shared getActualAudit(
        TrustLineID trustLineID) = 0;

    virtual const AuditRecord::Shared getActualAuditFull(
        TrustLineID trustLineID) = 0;

    virtual const AuditNumber getActualAuditNumber(
        TrustLineID trustLineID) = 0;

    virtual void deleteRecords(
        TrustLineID trustLineID) = 0;

    virtual void deleteAuditByNumber(
        TrustLineID trustLineID,
        AuditNumber auditNumber) = 0;

    virtual vector<AuditRecord::Shared> auditsLessEqualThanAuditNumber(
        TrustLineID trustLineID,
        AuditNumber auditNumber) = 0;

    virtual bool isContainsKeyHash(
        lamport::KeyHash::Shared keyHash) const = 0;
};

#endif //VTCPD_INTERFACES_AUDITHANDLER_H 