#include "OutgoingPaymentReceiptHandlerPostgreSQL.h"
#include <sstream>
#include "../../../common/serialization/BytesSerializer.h"

using namespace std;

namespace {
inline void checkCmd(PGconn *db, PGresult *res, const string &prefix) {
    if (PQresultStatus(res) != PGRES_COMMAND_OK) {
        string err = PQerrorMessage(db);
        PQclear(res);
        throw IOError(prefix + ": " + err);
    }
}
inline void checkTuples(PGconn *db, PGresult *res, const string &prefix) {
    if (PQresultStatus(res) != PGRES_TUPLES_OK) {
        string err = PQerrorMessage(db);
        PQclear(res);
        throw IOError(prefix + ": " + err);
    }
}
}

OutgoingPaymentReceiptHandlerPostgreSQL::OutgoingPaymentReceiptHandlerPostgreSQL(
    PGconn *dbConnection,
    const string &tableName,
    Logger &logger) :
    mDataBase(dbConnection),
    mTableName(tableName),
    mLog(logger)
{
    if (!mDataBase) {
        throw ValueError("OutgoingPaymentReceiptHandlerPostgreSQL: db connection null");
    }
    if (mTableName.empty()) {
        throw ValueError("OutgoingPaymentReceiptHandlerPostgreSQL: table name empty");
    }

    string query = "CREATE TABLE IF NOT EXISTS " + mTableName +
                   " (trust_line_id INTEGER NOT NULL, "
                   "audit_number INTEGER NOT NULL, "
                   "transaction_uuid BYTEA NOT NULL, "
                   "own_public_key_hash BYTEA NOT NULL, "
                   "amount BYTEA NOT NULL, "
                   "FOREIGN KEY(trust_line_id) REFERENCES trust_lines(id) ON DELETE CASCADE ON UPDATE CASCADE, "
                   "FOREIGN KEY(own_public_key_hash) REFERENCES own_keys(hash) ON DELETE CASCADE ON UPDATE CASCADE);";

    PGresult *res = PQexec(mDataBase, query.c_str());
    checkCmd(mDataBase, res, "OutgoingPaymentReceiptHandlerPostgreSQL::create table");
    PQclear(res);

    query = "CREATE UNIQUE INDEX IF NOT EXISTS " + mTableName + "_tl_audit_key_idx ON " + mTableName + "(trust_line_id, audit_number, own_public_key_hash);";
    res = PQexec(mDataBase, query.c_str());
    checkCmd(mDataBase, res, "OutgoingPaymentReceiptHandlerPostgreSQL::unique idx");
    PQclear(res);

    query = "CREATE INDEX IF NOT EXISTS " + mTableName + "_transaction_uuid_idx ON " + mTableName + "(transaction_uuid);";
    res = PQexec(mDataBase, query.c_str());
    checkCmd(mDataBase, res, "OutgoingPaymentReceiptHandlerPostgreSQL::uuid idx");
    PQclear(res);
#ifdef STORAGE_HANDLER_DEBUG_LOG
    info() << "OutgoingPaymentReceiptHandlerPostgreSQL initialized: table=" << mTableName;
#endif
}

void OutgoingPaymentReceiptHandlerPostgreSQL::saveRecord(
    const TrustLineID trustLineID,
    const AuditNumber auditNumber,
    const TransactionUUID &transactionUUID,
    const KeyHash::Shared ownPublicKeyHash,
    const TrustLineAmount &amount)
{
    if (!ownPublicKeyHash) {
        throw ValueError("saveRecord: ownPublicKeyHash null");
    }

    const string query = "INSERT INTO " + mTableName +
                         "(trust_line_id, audit_number, transaction_uuid, own_public_key_hash, amount) "
                         "VALUES ($1,$2,$3,$4,$5);";

    const int kParams = 5;
    const char *params[kParams];
    int lengths[kParams];
    int formats[kParams] = {0,0,1,1,1};

    string tlIdStr = to_string(trustLineID);
    string auditStr = to_string(auditNumber);

    params[0] = tlIdStr.c_str(); lengths[0]=0;
    params[1] = auditStr.c_str(); lengths[1]=0;

    BytesSerializer serializer;
    serializer.copy(transactionUUID);
    auto serializedUUID = serializer.collect();
    params[2] = reinterpret_cast<const char*>(serializedUUID.first.get()); lengths[2]=TransactionUUID::kBytesSize;

    params[3] = reinterpret_cast<const char*>(ownPublicKeyHash->data()); lengths[3]=KeyHash::kBytesSize;

    vector<byte_t> amountBytes = trustLineAmountToBytes(amount);
    params[4] = reinterpret_cast<const char*>(amountBytes.data()); lengths[4]=kTrustLineAmountBytesCount;

    PGresult *res = PQexecParams(mDataBase, query.c_str(), kParams, nullptr, params, lengths, formats, 0);
    checkCmd(mDataBase, res, "Outgoing saveRecord");
    PQclear(res);
#ifdef STORAGE_HANDLER_DEBUG_LOG
    info() << "Outgoing receipt saved TL=" << trustLineID << " audit=" << auditNumber;
#endif
}

map<TransactionUUID, TrustLineAmount> OutgoingPaymentReceiptHandlerPostgreSQL::auditAmounts(
    const TrustLineID trustLineID,
    const AuditNumber auditNumber)
{
    map<TransactionUUID, TrustLineAmount> result;
    const string query = "SELECT transaction_uuid, amount FROM " + mTableName + " WHERE trust_line_id=$1 AND audit_number=$2;";

    const char *params[2]; int lengths[2]={0,0}; int formats[2]={0,0};
    string tlIdStr=to_string(trustLineID); string auditStr=to_string(auditNumber);
    params[0]=tlIdStr.c_str(); params[1]=auditStr.c_str();

    PGresult *res = PQexecParams(mDataBase, query.c_str(),2,nullptr,params,lengths,formats,1);
    checkTuples(mDataBase,res,"auditAmounts");

    int rows = PQntuples(res);
    for (int i=0;i<rows;++i) {
        const unsigned char *uuidBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,0));
        const unsigned char *amountBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,1));

        TransactionUUID tUUID(uuidBytes);
        vector<byte_t> amountBuf(amountBytes, amountBytes + kTrustLineAmountBytesCount);
        result[tUUID] = bytesToTrustLineAmount(amountBuf);
    }
    PQclear(res);
    return result;
}

vector<ReceiptRecord::Shared> OutgoingPaymentReceiptHandlerPostgreSQL::receiptsByAuditNumber(
    const TrustLineID trustLineID,
    const AuditNumber auditNumber)
{
    vector<ReceiptRecord::Shared> result;
    const string query = "SELECT amount, transaction_uuid, own_public_key_hash FROM " + mTableName + " WHERE trust_line_id=$1 AND audit_number=$2;";

    const char *params[2]; int lengths[2]={0,0}; int formats[2]={0,0};
    string tlIdStr=to_string(trustLineID); string auditStr=to_string(auditNumber);
    params[0]=tlIdStr.c_str(); params[1]=auditStr.c_str();

    PGresult *res = PQexecParams(mDataBase, query.c_str(),2,nullptr,params,lengths,formats,1);
    checkTuples(mDataBase,res,"receiptsByAuditNumber");

    int rows = PQntuples(res);
    for (int i=0;i<rows;++i) {
        const unsigned char *amountBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,0));
        const unsigned char *uuidBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,1));
        const unsigned char *keyHashBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,2));

        vector<byte_t> amountBuf(amountBytes, amountBytes + kTrustLineAmountBytesCount);
        TransactionUUID tUUID(uuidBytes);
        auto keyHash = make_shared<KeyHash>(keyHashBytes);

        result.push_back(make_shared<ReceiptRecord>(auditNumber, tUUID, bytesToTrustLineAmount(amountBuf), keyHash, nullptr));
    }
    PQclear(res);
    return result;
}

vector<ReceiptRecord::Shared> OutgoingPaymentReceiptHandlerPostgreSQL::receiptsLessEqualThanAuditNumber(
    const TrustLineID trustLineID,
    const AuditNumber auditNumber)
{
    vector<ReceiptRecord::Shared> result;
    const string query = "SELECT amount, transaction_uuid, own_public_key_hash, audit_number FROM " + mTableName + " WHERE trust_line_id=$1 AND audit_number<=$2;";

    const char *params[2]; int lengths[2]={0,0}; int formats[2]={0,0};
    string tlIdStr=to_string(trustLineID); string auditStr=to_string(auditNumber);
    params[0]=tlIdStr.c_str(); params[1]=auditStr.c_str();

    PGresult *res = PQexecParams(mDataBase, query.c_str(),2,nullptr,params,lengths,formats,1);
    checkTuples(mDataBase,res,"receiptsLE");

    int rows = PQntuples(res);
    for (int i=0;i<rows;++i) {
        const unsigned char *amountBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,0));
        const unsigned char *uuidBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,1));
        const unsigned char *keyHashBytes = reinterpret_cast<const unsigned char*>(PQgetvalue(res,i,2));
        AuditNumber currentAudit = static_cast<AuditNumber>(atoi(PQgetvalue(res,i,3)));

        vector<byte_t> amountBuf(amountBytes, amountBytes + kTrustLineAmountBytesCount);
        TransactionUUID tUUID(uuidBytes);
        auto keyHash = make_shared<KeyHash>(keyHashBytes);

        result.push_back(make_shared<ReceiptRecord>(currentAudit, tUUID, bytesToTrustLineAmount(amountBuf), keyHash, nullptr));
    }
    PQclear(res);
    return result;
}

size_t OutgoingPaymentReceiptHandlerPostgreSQL::countReceiptsByNumber(
    const TrustLineID trustLineID,
    const AuditNumber auditNumber)
{
    const string query = "SELECT COUNT(transaction_uuid) FROM " + mTableName + " WHERE trust_line_id=$1 AND audit_number=$2;";
    const char *params[2]; int lengths[2]={0,0}; int formats[2]={0,0};
    string tlIdStr=to_string(trustLineID); string auditStr=to_string(auditNumber);
    params[0]=tlIdStr.c_str(); params[1]=auditStr.c_str();
    PGresult *res = PQexecParams(mDataBase, query.c_str(),2,nullptr,params,lengths,formats,0);
    checkTuples(mDataBase,res,"countReceipts");
    if (PQntuples(res)==0) { PQclear(res); throw IOError("countReceiptsByNumber: no result"); }
    size_t count = static_cast<size_t>(atoi(PQgetvalue(res,0,0)));
    PQclear(res);
    return count;
}

void OutgoingPaymentReceiptHandlerPostgreSQL::deleteRecords(
    const TransactionUUID &transactionUUID)
{
    const string query = "DELETE FROM " + mTableName + " WHERE transaction_uuid=$1;";
    const char *params[1]; int lengths[1]; int formats[1]={1};
    BytesSerializer serializer2;
    serializer2.copy(transactionUUID);
    auto serializedUUID2 = serializer2.collect();
    params[0]=reinterpret_cast<const char*>(serializedUUID2.first.get()); lengths[0]=TransactionUUID::kBytesSize;
    PGresult *res = PQexecParams(mDataBase, query.c_str(),1,nullptr,params,lengths,formats,0);
    checkCmd(mDataBase,res,"deleteRecords uuid");
    PQclear(res);
}

void OutgoingPaymentReceiptHandlerPostgreSQL::deleteRecords(
    const TrustLineID trustLineID)
{
    const string query = "DELETE FROM " + mTableName + " WHERE trust_line_id=$1;";
    const char *params[1]; int lengths[1]={0}; int formats[1]={0};
    string tlIdStr = to_string(trustLineID); params[0]=tlIdStr.c_str();
    PGresult *res = PQexecParams(mDataBase, query.c_str(),1,nullptr,params,lengths,formats,0);
    checkCmd(mDataBase,res,"deleteRecords TL");
    PQclear(res);
}

bool OutgoingPaymentReceiptHandlerPostgreSQL::isContainsKeyHash(
    KeyHash::Shared keyHash)
{
    if (!keyHash) throw ValueError("isContainsKeyHash: keyHash null");
    const string query = "SELECT own_public_key_hash FROM " + mTableName + " WHERE own_public_key_hash=$1 LIMIT 1;";
    const char *params[1]; int lengths[1]; int formats[1]={1};
    params[0]=reinterpret_cast<const char*>(keyHash->data()); lengths[0]=KeyHash::kBytesSize;
    PGresult *res = PQexecParams(mDataBase, query.c_str(),1,nullptr,params,lengths,formats,0);
    checkTuples(mDataBase,res,"containsKeyHash");
    bool result = PQntuples(res) > 0;
    PQclear(res);
    return result;
}

bool OutgoingPaymentReceiptHandlerPostgreSQL::isContainsTransaction(
    const TransactionUUID &transactionUUID)
{
    const string query = "SELECT transaction_uuid FROM " + mTableName + " WHERE transaction_uuid=$1 LIMIT 1;";
    const char *params[1]; int lengths[1]; int formats[1]={1};
    BytesSerializer serializer2;
    serializer2.copy(transactionUUID);
    auto serializedUUID2 = serializer2.collect();
    params[0]=reinterpret_cast<const char*>(serializedUUID2.first.get()); lengths[0]=TransactionUUID::kBytesSize;
    PGresult *res = PQexecParams(mDataBase, query.c_str(),1,nullptr,params,lengths,formats,0);
    checkTuples(mDataBase,res,"containsTransaction");
    bool result = PQntuples(res) > 0;
    PQclear(res);
    return result;
}

LoggerStream OutgoingPaymentReceiptHandlerPostgreSQL::info() const { return mLog.info(logHeader()); }
LoggerStream OutgoingPaymentReceiptHandlerPostgreSQL::warning() const { return mLog.warning(logHeader()); }
const string OutgoingPaymentReceiptHandlerPostgreSQL::logHeader() const { stringstream s; s << "[OutgoingPaymentReceiptHandlerPostgreSQL]"; return s.str(); } 