#include "FinalAmountsConfigurationMessage.h"
#include "../../../common/serialization/BytesDeserializer.h"

FinalAmountsConfigurationMessage::FinalAmountsConfigurationMessage(
    const SerializedEquivalent equivalent,
    vector<BaseAddress::Shared> senderAddresses,
    const TransactionUUID &transactionUUID,
    const vector<pair<PathID, ConstSharedTrustLineAmount>> &finalAmountsConfig,
    const map<PaymentNodeID, Contractor::Shared> &paymentParticipants,
    const BlockNumber maximalClaimingBlockNumber) :

    RequestMessageWithReservations(
        equivalent,
        senderAddresses,
        transactionUUID,
        finalAmountsConfig),
    mPaymentParticipants(paymentParticipants),
    mMaximalClaimingBlockNumber(maximalClaimingBlockNumber),
    mIsReceiptContains(false)
{
}

FinalAmountsConfigurationMessage::FinalAmountsConfigurationMessage(
    const SerializedEquivalent equivalent,
    vector<BaseAddress::Shared> senderAddresses,
    const TransactionUUID &transactionUUID,
    const vector<pair<PathID, ConstSharedTrustLineAmount>> &finalAmountsConfig,
    const map<PaymentNodeID, Contractor::Shared> &paymentParticipants,
    const BlockNumber maximalClaimingBlockNumber,
    const KeyNumber publicKeyNumber,
    const lamport::Signature::Shared signature,
    const lamport::KeyHash::Shared transactionPublicKeyHash) :

    RequestMessageWithReservations(
        equivalent,
        senderAddresses,
        transactionUUID,
        finalAmountsConfig),
    mPaymentParticipants(paymentParticipants),
    mMaximalClaimingBlockNumber(maximalClaimingBlockNumber),
    mIsReceiptContains(true),
    mPublicKeyNumber(publicKeyNumber),
    mSignature(signature),
    mTransactionPublicKeyHash(transactionPublicKeyHash)
{
}

FinalAmountsConfigurationMessage::FinalAmountsConfigurationMessage(
    BytesShared buffer) : RequestMessageWithReservations(buffer)
{
    auto currentOffset = RequestMessageWithReservations::kOffsetToInheritedBytes();
    BytesDeserializer deserializer(buffer, currentOffset);

    //----------------------------------------------------
    SerializedRecordsCount paymentParticipantsCount;
    deserializer.copyInto(&paymentParticipantsCount);
    currentOffset += BytesSerializer::kSerializedRecordsCountSize;
    //-----------------------------------------------------
    for (SerializedRecordNumber idx = 0; idx < paymentParticipantsCount; idx++) {
        PaymentNodeID paymentNodeID;
        deserializer = BytesDeserializer(buffer, currentOffset);
        deserializer.copyInto(&paymentNodeID);
        currentOffset += BytesSerializer::kSerializedPaymentNodeIDSize;
        //---------------------------------------------------
        auto contractor = make_shared<Contractor>(buffer.get() + currentOffset);
        currentOffset += contractor->serializedSize();
        //---------------------------------------------------
        mPaymentParticipants.insert(
            make_pair(
                paymentNodeID,
                contractor));
    }
    //----------------------------------------------------
    deserializer = BytesDeserializer(buffer, currentOffset);
    deserializer.copyInto(&mMaximalClaimingBlockNumber);
    currentOffset += BytesSerializer::kSerializedBlockNumberSize;
    //----------------------------------------------------
    deserializer = BytesDeserializer(buffer, currentOffset);
    deserializer.copyInto(&mIsReceiptContains);
    //----------------------------------------------------
    if (mIsReceiptContains) {
        currentOffset += BytesSerializer::kSerializedByteSize;
        deserializer = BytesDeserializer(buffer, currentOffset);
        deserializer.copyInto(&mPublicKeyNumber);
        currentOffset += BytesSerializer::kSerializedKeyNumberSize;

        auto signature = make_shared<lamport::Signature>(
                             buffer.get() + currentOffset);
        mSignature = signature;
        currentOffset += lamport::Signature::signatureSize();

        mTransactionPublicKeyHash = make_shared<lamport::KeyHash>(
                                        buffer.get() + currentOffset);
    }
}

const Message::MessageType FinalAmountsConfigurationMessage::typeID() const
{
    return Message::Payments_FinalAmountsConfiguration;
}

const map<PaymentNodeID, Contractor::Shared> &FinalAmountsConfigurationMessage::paymentParticipants() const
{
    return mPaymentParticipants;
}

const BlockNumber FinalAmountsConfigurationMessage::maximalClaimingBlockNumber() const
{
    return mMaximalClaimingBlockNumber;
}

bool FinalAmountsConfigurationMessage::isReceiptContains() const
{
    return mIsReceiptContains;
}

const KeyNumber FinalAmountsConfigurationMessage::publicKeyNumber() const
{
    return mPublicKeyNumber;
}

const lamport::Signature::Shared FinalAmountsConfigurationMessage::signature() const
{
    return mSignature;
}

const lamport::KeyHash::Shared FinalAmountsConfigurationMessage::transactionPublicKeyHash() const
{
    return mTransactionPublicKeyHash;
}

pair<BytesShared, size_t> FinalAmountsConfigurationMessage::serializeToBytes() const
{
    auto parentBytesAndCount = RequestMessageWithReservations::serializeToBytes();
    size_t bytesCount = parentBytesAndCount.second + sizeof(SerializedRecordsCount) + sizeof(BlockNumber) + sizeof(byte_t);
    for (const auto &participant : mPaymentParticipants) {
        bytesCount += sizeof(PaymentNodeID) + participant.second->serializedSize();
    }
    if (mIsReceiptContains) {
        bytesCount += sizeof(KeyNumber) + lamport::Signature::signatureSize() + lamport::KeyHash::kBytesSize;
    }

    BytesShared buffer = tryMalloc(bytesCount);

    auto initialOffset = buffer.get();
    memcpy(
        initialOffset,
        parentBytesAndCount.first.get(),
        parentBytesAndCount.second);
    auto bytesBufferOffset = initialOffset + parentBytesAndCount.second;

    //----------------------------------------------------
    auto paymentParticipantsCount = (SerializedRecordsCount)mPaymentParticipants.size();
    memcpy(
        bytesBufferOffset,
        &paymentParticipantsCount,
        sizeof(SerializedRecordsCount));
    bytesBufferOffset += sizeof(SerializedRecordsCount);
    //----------------------------------------------------
    for (auto const &paymentNodeIdAndContractor : mPaymentParticipants) {
        memcpy(
            bytesBufferOffset,
            &paymentNodeIdAndContractor.first,
            sizeof(PaymentNodeID));
        bytesBufferOffset += sizeof(PaymentNodeID);

        auto contractorSerializedData = paymentNodeIdAndContractor.second->serializeToBytes();
        memcpy(
            bytesBufferOffset,
            contractorSerializedData.get(),
            paymentNodeIdAndContractor.second->serializedSize());
        bytesBufferOffset += paymentNodeIdAndContractor.second->serializedSize();
    }
    //----------------------------------------------------
    memcpy(
        bytesBufferOffset,
        &mMaximalClaimingBlockNumber,
        sizeof(BlockNumber));
    bytesBufferOffset += sizeof(BlockNumber);
    //----------------------------------------------------
    memcpy(
        bytesBufferOffset,
        &mIsReceiptContains,
        sizeof(byte_t));
    //----------------------------------------------------
    if (mIsReceiptContains) {
        bytesBufferOffset += sizeof(byte_t);
        memcpy(
            bytesBufferOffset,
            &mPublicKeyNumber,
            sizeof(KeyNumber));
        bytesBufferOffset += sizeof(KeyNumber);

        memcpy(
            bytesBufferOffset,
            mSignature->data(),
            mSignature->signatureSize());
        bytesBufferOffset += lamport::Signature::signatureSize();

        memcpy(
            bytesBufferOffset,
            mTransactionPublicKeyHash->data(),
            lamport::KeyHash::kBytesSize);
    }
    //----------------------------------------------------
    return make_pair(
               buffer,
               bytesCount);
}
