#ifndef VTCPD_CYCLESMANAGER_H
#define VTCPD_CYCLESMANAGER_H

#include "../transactions/scheduler/TransactionsScheduler.h"
#include "../transactions/transactions/regular/payments/base/BasePaymentTransaction.h"
#include "../paths/lib/Path.h"
#include "../logger/Logger.h"
#include "../common/time/TimeUtils.h"
#include "../subsystems_controller/SubsystemsController.h"
#include "CyclesRunningParameters.h"

#include <boost/signals2.hpp>
#include <boost/asio.hpp>
#include <boost/asio/steady_timer.hpp>

#include <vector>
#include <map>

namespace as = boost::asio;
namespace signals = boost::signals2;

class CyclesManager
{
public:
    enum CycleClosingState
    {
        ThreeNodes = 1,
        FourNodes,
        FiveNodes,
        SixNodes
    };

public:
    typedef signals::signal<void(const SerializedEquivalent)> BuildSixNodesCyclesSignal;
    typedef signals::signal<void(const SerializedEquivalent)> BuildFiveNodesCyclesSignal;
    typedef signals::signal<void(const SerializedEquivalent, Path::Shared)> CloseCycleSignal;

public:
    CyclesManager(
        const SerializedEquivalent equivalent,
        TransactionsScheduler *transactionsScheduler,
        as::io_context &ioCtx,
        CyclesRunningParameters cyclesRunningParameters,
        Logger &logger,
        SubsystemsController *subsystemsController);

    void closeOneCycle(
        bool nextCycleShouldBeRunned = false);

    void addCycle(
        Path::Shared);

    bool resolveReservationConflict(
        const TransactionUUID &challengerTransactionUUID,
        const TransactionUUID &reservedTransactionUUID);

    bool isTransactionStillAlive(
        const TransactionUUID &transactionUUID);

    void addClosedTrustLine(
        BaseAddress::Shared source,
        BaseAddress::Shared destination);

    void addOfflineNode(
        BaseAddress::Shared nodeAddress);

private:
    void runSignalSixNodes(
        const boost::system::error_code &err);

    void runSignalFiveNodes(
        const boost::system::error_code &err);

    void updateOfflineNodesAndClosedTLLists(
        const boost::system::error_code &err);

    vector<Path::Shared> *cyclesVector(
        CycleClosingState currentCycleClosingState);

    void incrementCurrentCycleClosingState();

    bool isChallengerTransactionWinReservation(
        BasePaymentTransaction::Shared challengerTransaction,
        BasePaymentTransaction::Shared reservedTransaction);

    void clearClosedCycles();

    void removeCyclesWithClosedTrustLine(
        BaseAddress::Shared sourceClosed,
        BaseAddress::Shared destinationClosed,
        vector<Path::Shared> &cycles);

    void removeCyclesWithOfflineNode(
        BaseAddress::Shared offlineNode,
        vector<Path::Shared> &cycles);

    uint32_t randomInitializer() const;

    LoggerStream info() const;

    LoggerStream debug() const;

    LoggerStream warning() const;

    const string logHeader() const;

public:
    mutable CloseCycleSignal closeCycleSignal;

    mutable BuildSixNodesCyclesSignal buildSixNodesCyclesSignal;

    mutable BuildFiveNodesCyclesSignal buildFiveNodesCyclesSignal;

private:
#ifdef TESTS
    const uint32_t kSignalStartTimeSecondsTests = 15;
    const uint32_t kSignalRepeatTimeSecondsTests = 10;
#endif
    const uint32_t kUpdatingTimerPeriodSeconds = 10 * 60;

    static const byte_t kOfflineNodesAndClosedTLLiveHours = 0;
    static const byte_t kOfflineNodesAndClosedTLLiveMinutes = 30;
    static const byte_t kOfflineNodesAndClosedTLLiveSeconds = 0;

    static Duration &kOfflineNodesAndClosedTLLiveDuration()
    {
        static auto duration = Duration(
                                   kOfflineNodesAndClosedTLLiveHours,
                                   kOfflineNodesAndClosedTLLiveMinutes,
                                   kOfflineNodesAndClosedTLLiveSeconds);
        return duration;
    }

private:
    TransactionsScheduler *mTransactionScheduler;
    SerializedEquivalent mEquivalent;
    as::io_context &mIOCtx;
    CyclesRunningParameters mCyclesRunningParameters;

    vector<Path::Shared> mThreeNodesCycles;
    vector<Path::Shared> mFourNodesCycles;
    vector<Path::Shared> mFiveNodesCycles;
    vector<Path::Shared> mSixNodesCycles;

    map<DateTime, pair<BaseAddress::Shared, BaseAddress::Shared>> mClosedTrustLines;
    map<DateTime, BaseAddress::Shared> mOfflineNodes;

    CycleClosingState mCurrentCycleClosingState;
    Logger &mLog;

    unique_ptr<as::steady_timer> mSixNodesCycleTimer;
    unique_ptr<as::steady_timer> mFiveNodesCycleTimer;
    unique_ptr<as::steady_timer> mUpdatingTimer;

    // prevent launching closing cycle if another one in closing process
    bool mIsCycleInProcess;

    SubsystemsController *mSubsystemsController;
};

#endif // VTCPD_CYCLESMANAGER_H
