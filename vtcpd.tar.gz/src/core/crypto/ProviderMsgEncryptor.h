#ifndef VTCPD_PROVIDERMSGENCRYPTOR_H
#define VTCPD_PROVIDERMSGENCRYPTOR_H

#include <sodium.h>
#include "../common/memory/MemoryUtils.h"
#include "../common/time/TimeUtils.h"

class ProviderMsgEncryptor
{

public:
    typedef pair<BytesShared, size_t> Buffer;
    struct PublicKey
    {
        typedef std::shared_ptr<PublicKey> Shared;
        static const size_t kBytesSize = crypto_aead_aes256gcm_KEYBYTES;
        PublicKey() {}
        explicit PublicKey(const string &str);
        byte_t key[kBytesSize];
    };

public:
    explicit ProviderMsgEncryptor(
        const PublicKey::Shared &publicKey);

    Buffer encrypt(
        byte_t* bytesForEncryption,
        size_t size);

protected:
    PublicKey::Shared mPublicKey = nullptr;
};

#endif // VTCPD_PROVIDERMSGENCRYPTOR_H
