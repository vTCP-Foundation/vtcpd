#ifndef VTCPD_EQUIVALENTSCYCLESSUBSYSTEMSROUTER_H
#define VTCPD_EQUIVALENTSCYCLESSUBSYSTEMSROUTER_H

#include "../cycles/CyclesManager.h"
#include "../cycles/RoutingTableManager.h"
#include "../transactions/scheduler/TransactionsScheduler.h"
#include "../subsystems_controller/SubsystemsController.h"
#include "../delayed_tasks/GatewayNotificationAndRoutingTablesDelayedTask.h"

#include <map>

namespace as = boost::asio;
namespace signals = boost::signals2;

class EquivalentsCyclesSubsystemsRouter
{

public:
    typedef signals::signal<void(const SerializedEquivalent equivalent)> BuildSixNodesCyclesSignal;
    typedef signals::signal<void(const SerializedEquivalent equivalent)> BuildFiveNodesCyclesSignal;
    typedef signals::signal<void(
        const SerializedEquivalent equivalent,
        Path::Shared cycle)> CloseCycleSignal;
    typedef signals::signal<void()> GatewayNotificationSignal;

public:
    EquivalentsCyclesSubsystemsRouter(
        TransactionsScheduler *transactionScheduler,
        SubsystemsController *subsystemsController,
        as::io_context &ioCtx,
        vector<SerializedEquivalent> equivalents,
        CyclesRunningParameters cyclesRunningParameters,
        Logger &logger);

    CyclesManager* cyclesManager(
        const SerializedEquivalent equivalent) const;

    RoutingTableManager* routingTableManager(
        const SerializedEquivalent equivalent) const;

    void initNewEquivalent(
        const SerializedEquivalent equivalent);

    void clearRoutingTables();

public:
    mutable CloseCycleSignal closeCycleSignal;

    mutable BuildSixNodesCyclesSignal buildSixNodesCyclesSignal;

    mutable BuildFiveNodesCyclesSignal buildFiveNodesCyclesSignal;

    mutable GatewayNotificationSignal gatewayNotificationSignal;

protected:
    string logHeader() const;

    LoggerStream warning() const;

    LoggerStream error() const;

    LoggerStream info() const;

    LoggerStream debug() const;

private:
    void connectSignalsToSlots();

    void subscribeForBuildingFiveNodesCycles(
        CyclesManager::BuildFiveNodesCyclesSignal &signal);

    void subscribeForBuildingSixNodesCycles(
        CyclesManager::BuildSixNodesCyclesSignal &signal);

    void subscribeForClosingCycles(
        CyclesManager::CloseCycleSignal &signal);

    void subscribeForGatewayNotification(
        GatewayNotificationAndRoutingTablesDelayedTask::GatewayNotificationSignal &signal);

    void onBuildCycleFiveNodesSlot(
        const SerializedEquivalent equivalent);

    void onBuildCycleSixNodesSlot(
        const SerializedEquivalent equivalent);

    void onCloseCycleSlot(
        const SerializedEquivalent equivalent,
        Path::Shared cycle);

    void onGatewayNotificationSlot();

private:
    as::io_context &mIOCtx;
    TransactionsScheduler *mTransactionScheduler;
    SubsystemsController *mSubsystemsController;
    CyclesRunningParameters mCyclesRunningParameters;
    Logger &mLogger;
    map<SerializedEquivalent, unique_ptr<CyclesManager>> mCyclesManagers;
    map<SerializedEquivalent, unique_ptr<RoutingTableManager>> mRoutingTablesManagers;
    unique_ptr<GatewayNotificationAndRoutingTablesDelayedTask> mGatewayNotificationAndRoutingTablesDelayedTask;
};


#endif //VTCPD_EQUIVALENTSCYCLESSUBSYSTEMSROUTER_H
